#include <stdio.h>

int main()
{
    int arr[100];
    int num, s_arr, element_arr;
    int flag=1;
    printf("Enter the given number: ");
    scanf("%d",&num);
    printf("Enter the size of the array: ");
    scanf("%d",&s_arr);
    printf("Enter the elements of the array:\n");
    for (int i=0;i<s_arr;i++)
    {
        scanf("%d",&element_arr);
        arr[i]=element_arr;
    }

    printf("The indices:\n");
    for(int k=0; k<s_arr; k++)
    {
        for(int j=flag; j<s_arr; j++)
        {
            if(arr[k]+arr[j]==num)
            {
                printf("%d %d\n",k,j);
                break;
            }
        }
        flag++;
    }
    return 0;
}