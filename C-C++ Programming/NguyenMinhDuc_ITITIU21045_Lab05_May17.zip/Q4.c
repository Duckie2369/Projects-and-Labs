#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int solve(int, int, int);
void move(void);
int next_x(int, int);
int next_y(int, int);

int grid[8][8]={0};

void move()
{
    for (int i=0; i<8; i++)
    {
        for (int j=0; j<8; j++)
        {
            printf("%d ", grid[j][i]);
        }
        printf("\n");
    }
    printf("\n\n\n");
}

int next_x(int x, int move)
{
    if (move == 0)
        x += 1;
    else if (move == 1)
        x += 2;
    else if (move == 2)
        x += 2;
    else if (move == 3)
        x += 1;
    else if (move == 4)
        x -= 1;
    else if (move == 5)
        x -= 2;
    else if (move == 6)
        x -= 2;
    else if (move == 7)
        x -= 1;
    
    if (x < 0 || x > 7)
        return -1;
    else
        return x;
}

int next_y(int y, int move)
{
    if (move == 0)
        y -= 2;
    else if (move == 1)
        y -= 1;
    else if (move == 2)
        y += 1;
    else if (move == 3)
        y += 2;
    else if (move == 4)
        y += 2;
    else if (move == 5)
        y += 1;
    else if (move == 6)
        y -= 1;
    else if (move == 7)
        y -= 2;
    
    if (y < 0 || y > 7)
        return -1;
    else
        return y;
}
int solve(int x, int y, int num)
{
    int moveNum = 0;

    if (num == 64)
        return 1;
    if (grid[x][y] == 0)
    {
        while (moveNum < 8)
        {
            if ((next_x(x, moveNum) != -1) && (next_y(y, moveNum) != -1))
            {
                grid[x][y] = num;
                if (solve(next_x(x, moveNum), next_y(y, moveNum), num+1))
                    return 1;
            }
            moveNum++;
        }
        grid[x][y]=0;
    }
    return 0;
}

int main()
{
    srand(time(NULL));
    int x = rand() % 8, y = rand() % 8;
    solve(x, y, 0);
    move();
    return 0;
}