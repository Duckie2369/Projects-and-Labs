#include <stdio.h>
#include <string.h>

int longestSubstring(char * s)
{
    int i,j,length,max_len=0;
    int freq[256]={0};

    for (i=0; s[i]!=0; i++)
    {
        length=0;
        memset(freq,0,sizeof(freq));
        for (j=i+1;s[j]!=0;j++)
        {
            if (freq[s[j]]==0)
            {
                freq[s[j]]++;
                length++;
            }
            else
                break;
        }
        if (length>max_len)
            max_len=length;
    }
    return max_len;
}
int main()
{
    char *c="aabcabcbb";
    printf("The input string is ");
    for (int m=0;m<strlen(c);m++)
        printf("%c",c[m]);
    printf("\nLength = %d",longestSubstring(c));
    return 0;
}
