#include <stdio.h>

int main()
{
    int p[10], n[10][10], a[10];
    int sp,sn,element_p,element_n_p, element_a;

    printf("Enter size of vector p and n: ");
    scanf("%d %d",&sp , &sn);
    printf("Enter the elements of vector p:\n");
    for (int i=0;i<sp;i++)
    {
        scanf("%d",&element_p);
        p[i]=element_p;
    }

    printf("Enter the matrix n*p:\n");
    for (int j=0; j<sn; j++)
    {
        for (int k=0; k<sp; k++)
        {
            scanf("%d",&element_n_p);
            n[j][k]=element_n_p;
        }    
    }

    for (int m=0; m<sn; m++)
    {
        for (int b=0; b<sp; b++)
        {
            element_a += p[b]*n[m][b];
        }
        a[m]=element_a;
        element_a=0;
    }

    printf("Product of n*p matrix and vector p:\n");
    for(int l=0;l<sn;l++)
        printf("%d ",a[l]);
    return 0;
}