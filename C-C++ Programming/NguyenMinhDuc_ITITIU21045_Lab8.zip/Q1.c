#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main()
{
    char str[10];
    printf("Enter the date: ");
    scanf("%s",str);
    int m=(int)(str[1]);
    if (str[0]=='0')
    {
        if (str[1]=='1')
            printf("%s %c%c, %c%c%c%c","January",str[3],str[4],str[6],str[7],str[8],str[9]);

        if (str[1]=='2')
            printf("%s %c%c, %c%c%c%c","February",str[3],str[4],str[6],str[7],str[8],str[9]);
        
        if (str[1]=='3')
            printf("%s %c%c, %c%c%c%c","March",str[3],str[4],str[6],str[7],str[8],str[9]);

        if (str[1]=='4')
            printf("%s %c%c, %c%c%c%c","April",str[3],str[4],str[6],str[7],str[8],str[9]);

        if (str[1]=='5')
            printf("%s %c%c, %c%c%c%c","May",str[3],str[4],str[6],str[7],str[8],str[9]);

        if (str[1]=='6')
            printf("%s %c%c, %c%c%c%c","June",str[3],str[4],str[6],str[7],str[8],str[9]);

        if (str[1]=='7')
            printf("%s %c%c, %c%c%c%c","July",str[3],str[4],str[6],str[7],str[8],str[9]);

        if (str[1]=='8')
            printf("%s %c%c, %c%c%c%c","August",str[3],str[4],str[6],str[7],str[8],str[9]);

        if (str[1]=='9')
            printf("%s %c%c, %c%c%c%c","September",str[3],str[4],str[6],str[7],str[8],str[9]);
    }
    else
    {
        if (str[1]=='0')
            printf("%s %c%c, %c%c%c%c","October",str[3],str[4],str[6],str[7],str[8],str[9]);

        if (str[1]=='1')
            printf("%s %c%c, %c%c%c%c","November",str[3],str[4],str[6],str[7],str[8],str[9]);

        if (str[1]=='2')
            printf("%s %c%c, %c%c%c%c","December",str[3],str[4],str[6],str[7],str[8],str[9]);
    }
    return 0;
}