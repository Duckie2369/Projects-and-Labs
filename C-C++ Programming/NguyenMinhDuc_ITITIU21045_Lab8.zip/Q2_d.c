#include<stdio.h>
struct student
{
     int id;
     char name[20];
     float GPA;
}stud[3];
int main()
{
     int i,j;
     float max_GPA;
     struct student s;
     for(i=0;i<3;i++)
     {
          printf("Enter ID, name and GPA for Student-%d \n",i+1);
          printf("-----------------------------------\n");
          scanf("%d",&stud[i].id);
          scanf("%s",stud[i].name);
          scanf("%f",&stud[i].GPA);
          printf("\n-----------------------------------\n");
     }
     for(i=0;i<3;i++)
     {
          for(j=i+1;j<3;j++)
          {
               if(stud[i].GPA<stud[j].GPA)
               {
                    s=stud[i];
                    stud[i]=stud[j];
                    stud[j]=s;
               }
          }
     }
     printf("Descending Order.\n");
     printf("\n-----------------------------------\n");
     for(i=0;i<3;i++)
     {
          printf("\n%d\t%s\t%f",stud[i].id,stud[i].name,stud[i].GPA);
     }
     return 0;
}