#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

struct student
{
    int ID;
    char name[40];
    float GPA;
};

void updateInfo()
{
    FILE *UpdateInfo;
    int id;
    printf("%s", "Enter ID to update: ");
    scanf("%d", &id);
    fseek(UpdateInfo, (id - 1) * sizeof(struct student), SEEK_SET); 
    struct student stud ={0,"",0.0};

    fread(&stud, sizeof(struct student), 1, UpdateInfo);
    if (id == 0) 
    {
        puts("File could not be opened");
    }
    else 
    {
                printf("Enter new ID, name and GPA\n?");
                scanf("%d%s%f", &stud.ID, stud.name, &stud.GPA );

                fseek (UpdateInfo, (stud.ID-1)*(sizeof(stud)), SEEK_SET);

                fwrite (&stud, sizeof(struct student), 1, UpdateInfo);
    }
        
    fclose (UpdateInfo);
}
int main(void)
{
    FILE *students;
    if ((students = fopen("students.txt","rb+")) == NULL) 
    {
        puts("File could not be opened");
    }
    else 
    {
        updateInfo(students);
    }
    return 0;
}