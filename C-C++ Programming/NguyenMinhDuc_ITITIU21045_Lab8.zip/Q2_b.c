#include <stdio.h>

struct student
{
    int ID;
    char name[40];
    float GPA;
};

int main(void)
{
    FILE *students;
    if ((students = fopen("students.txt","w")) == NULL) 
    {
        puts("File could not be opened");
    }
    else 
    {
        struct student st = {0, "", 0.0};
        puts("Enter the ID, name and GPA.");
        puts("Enter EOF to end input.");
        printf("%s", "? ");

        scanf("%d%30s%f", &st.ID, st.name, &st.GPA);

        while (!feof(stdin)) 
        {
            fprintf(students, "%d %s %f\n", st.ID, st.name, st.GPA);
            printf("%s", "? ");
            scanf("%d%29s%f", &st.ID, st.name, &st.GPA);
        }

        fclose(students);
    }
}