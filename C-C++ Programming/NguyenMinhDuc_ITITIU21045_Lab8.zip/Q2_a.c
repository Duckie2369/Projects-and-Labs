#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

struct student
{
    int ID;
    char name[40];
    float GPA;
};

int main()
{
    struct student st[5];
    for (int i=0;i<5;i++)
    {
        printf("Enter the ID, name, GPA of student %d:\n",i+1);
        scanf("%d",&st[i].ID);
        scanf("%s",&st[i].name);
        scanf("%f",&st[i].GPA);
    }
    for (int k=0;k<5;k++)
    {
        printf("Student %d:\n",k+1);
        printf("%d\t%s\t%f\n",st[k].ID,st[k].name,st[k].GPA);
    }
    
    return 0;
}
