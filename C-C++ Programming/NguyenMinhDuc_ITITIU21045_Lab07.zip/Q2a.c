#include <stdio.h>

struct person
{
    int ID;
    char first_name[21];
    char last_name[21];
    int age;
    char phone[10];
};

int main()
{
    struct person ps[5];
    for (int i=0;i<5;i++)
    {
        printf("Person %d:\n",i+1);
        scanf("%d",&ps[i].ID);
        scanf("%s",&ps[i].first_name);
        scanf("%s",&ps[i].last_name);
        scanf("%d",&ps[i].age);
        scanf("%s",&ps[i].phone);
    }
    return 0;
}