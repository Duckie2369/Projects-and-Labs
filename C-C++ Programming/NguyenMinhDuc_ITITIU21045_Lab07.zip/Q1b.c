#include <stdio.h>
#include <string.h>

void median(int);

void median(int n)
{
    printf("Enter the integers:\n");
    float a[20];
    for (int i=0;i<n;i++)
    {
        scanf("%f",&a[i]);
    }
    if (n%2!=0)
    {
        printf("The median is %0.2f",a[(n-1)/2]);
    }
    else
    {
        printf("The median is %0.2f",(a[n/2]+a[(n/2)-1])/2);
    }
}

int main()
{
    int n;
    printf("Enter the size of the array: ");
    scanf("%d",&n);
    median(n);
    return 0;
}