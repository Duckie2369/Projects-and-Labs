#include <stdio.h>
#define SIZE 10
void sort_array( int *, const int );

void swap( int *num_before, int *num_after )
{
    int temp = *num_before;
    *num_before = *num_after;
    *num_before = temp;
}

void sort_array( int *a, const int size )
{
    void swap( int *, int * );
    int pass, j;
    for ( pass = 0; pass < size - 1; pass++ )
    {
        for ( j = 0; j < size - 1; j++ )
        {
            if ( a[ j ] > a[ j + 1 ] ) 
                swap( &a[ j ], &a[ j + 1 ] );
        }
    }
}

int main()
{
    int a[ SIZE ] = { 2, 6, 4, 8, 10, 12, 89, 68, 45, 37 };

    printf( "Data items in original order\n" );

    for (int i = 0; i < SIZE; i++ )
        printf( "%4d", a[ i ] );

    sort_array( a, SIZE );
    printf( "\nData items in ascending order\n" );

    for (int k = 0; k < SIZE; k++ )
    printf( "%4d", a[ k] );
    
    printf( "\n" );

    return 0;
}



