#include <stdio.h>
#include <string.h>

void delete(char string[], char substr[]);

int main()
{
  char str[100],word[10];
  printf("Enter the string:\n");
  gets(str);
  printf("Enter the word: ");
  gets(word);
  delete(str, word);
  printf("New line: %s\n", str);
  return 0;
}

// deletes all occurrences of substr that occur in string
void delete(char string[], char substr[])
{
  int i = 0;

  int string_length = strlen(string);
  int substr_length = strlen(substr);
  
  while (i < string_length)
  {
    if (strstr(&string[i], substr) == &string[i])
    {
      string_length -= substr_length;
    
      for (int j = i; j < string_length; j++)
        string[j] = string[j + substr_length];
    }
    else i++;
  }
  string[i] = '\0';
}