#include <stdio.h>
#include <stdio.h>
#include <math.h>

struct m_and_SD
{
    float m;
    float SD;
};

void mean_and_SD(int);
 
void mean_and_SD(int n)
{
    int i;
    float num[25];
    float sum;

    struct m_and_SD array;
    
    printf("Enter the value of elements: \n");
    for (i = 0; i < n; i++ )
        scanf("%f", &num[i]);
    
    for (i = 0; i < n; i++)
        sum += num[i];

    array.m = sum / n;

    sum = 0;
    for (i = 0; i < n; i++)
        sum += (num[i] - array.m) * (num[i] - array.m);

    array.SD = sqrt(sum / n);

    printf("Mean: %.6f \n", array.m);
    printf("Standard Deviation: %.6f", array.SD);
}

int main()
{
    int n;
    printf("Enter size of the array: ");
    scanf("%d", &n);
    mean_and_SD(n);
    return 0;
}
