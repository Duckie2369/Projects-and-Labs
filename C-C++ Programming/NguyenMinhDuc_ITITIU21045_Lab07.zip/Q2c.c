#include <stdio.h>

struct person
{
    int ID;
    char first_name[21];
    char last_name[21];
    int age;
    char phone[10];
};

void highest_age(struct person ps[5])
{
    int max_age;
    for (int k=0;k<5;k++)
    {
        if (max_age<=ps[k].age)
        {
            max_age=ps[k].age;
        }
    }
    for (int i=0;i<5;i++)
    {
        printf("\nHighest age staff:\n");
        if (max_age==ps[i].age)
        {
            printf("%d\n",ps[i].ID);
            printf("%s\n",ps[i].first_name);
            printf("%s\n",ps[i].last_name);
            printf("%d\n",ps[i].age);
            printf("%s\n",ps[i].phone);
        }
    
    }
}

int main()
{
    int id;
    struct person ps[5];
    for (int i=0;i<5;i++)
    {
        printf("Person %d:\n",i+1);
        scanf("%d",&ps[i].ID);
        scanf("%s",&ps[i].first_name);
        scanf("%s",&ps[i].last_name);
        scanf("%d",&ps[i].age);
        scanf("%s",&ps[i].phone);
    }
    highest_age(ps);
    return 0;
}