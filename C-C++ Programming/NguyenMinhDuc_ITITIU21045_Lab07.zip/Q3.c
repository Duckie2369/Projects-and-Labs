#include <stdio.h>

struct time
{
    int h;
    int m;
    int s;
};

int main()
{
    struct time t[2];
    for (int i=0;i<2;i++)
    {
        printf("Time %d (hours, minutes, seconds):",i);
        scanf("%d",&t[i].h);
        scanf("%d",&t[i].m);
        scanf("%d",&t[i].s);
    }
    printf("Time elasped: %d : %d : %d",t[1].h-t[0].h,t[1].m-t[0].m,t[1].s-t[0].s);
    return 0;
}