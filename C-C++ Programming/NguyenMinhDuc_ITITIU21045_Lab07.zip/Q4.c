#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int main()
{
    char a[100];
    printf("Enter the line:\n");
    gets(a);
    int count_vowel=0,count_digit=0,count_space=0,count_consonants=0;
    for (int i=0;a[i]!='\0';i++)
    {
        if(a[i]=='a' || a[i]=='e' || a[i]=='i' || a[i]=='o' || a[i]=='u')
            count_vowel +=1;
        else if(a[i]==' ')
            count_space+=1;
        else if(a[i]=='0' || a[i]=='1' || a[i]=='2' || a[i]=='3' || a[i]=='4' || a[i]=='5' || a[i]=='6' || a[i]=='7' || a[i]=='8' || a[i]=='9')
            count_digit+=1;
        else
            count_consonants+=1;
    }
    printf("Vowels: %d\nConsonants: %d\nDigits: %d\nWhite spaces: %d\n",count_vowel,count_consonants,count_digit,count_space);
    return 0;
}