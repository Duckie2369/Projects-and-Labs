#include <stdio.h>

int main()
{
    int n;
    char num_word[10] [10]= {"", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
    char teen_num_word[10] [10]= {"", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"};
    char tenth_num_word[10] [10]= {"", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"};
    printf("Enter a maximum 4-digit number: ");
    scanf("%d",&n);

    int thou = n/1000, hund = (n-thou*1000)/100,  tenth = (n-thou*1000-hund*100)/10, digit = n%10;

    if (n>1000 && n<=9999)
    {
        if (hund==0 && tenth != 1)
        {
            printf("%s thousand %s %s", num_word[thou], tenth_num_word[tenth], num_word[digit]);
        }
        else if (hund==0 && tenth == 1)
        {
            printf("%s thousand %s", num_word[thou], teen_num_word[digit]);
        }
        else if (hund!=0 && tenth != 1)
        {
            printf("%s thousand %s hundred %s %s", num_word[thou] ,num_word[hund], tenth_num_word[tenth], num_word[digit]);
        }
        else
        {
            printf("%s thousand %s hundred %s", num_word[thou] ,num_word[hund], teen_num_word[digit]);
        }
    }
    else if (n<1000 && n>=100)
    {
        if (tenth != 1)
            printf("%s hundred %s %s",num_word[hund], tenth_num_word[tenth], num_word[digit]);
        else
            printf("%s hundred %s",num_word[hund], teen_num_word[digit]);
    }
    else if (n<100 && n>=20)
    {
        printf("%s %s", tenth_num_word[tenth], num_word[digit]);
    }
    else if (n<20 && n>10)
    {
        printf("%s", teen_num_word[digit]);
    }
    else
    {
        printf("%s", num_word[n]);
    }
    return 0;
}