#include<stdio.h>
#include<string.h>
int main()
{
   int i,j,count;
   char string[25][25],temp[25];
   puts("Number of words?: ");
   scanf("%d",&count);

   puts("Enter words one by one: ");
   for(i=0; i<=count; i++)
        gets(string[i]);
   for(i=0;i<=count;i++)
      for(j=i+1;j<=count;j++)
      {
         if(strcmp(string[i],string[j])>0)
         {
            strcpy(temp,string[i]);
            strcpy(string[i],string[j]);
            strcpy(string[j],temp);
         }
      }
   printf("Order of Sorted Strings:");
   for(i=0;i<=count;i++)
      puts(string[i]);
   
   return 0;
}
