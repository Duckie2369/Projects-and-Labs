#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int i;
  char s[100], st[101];
  printf("Enter the string: ");
  gets(s);
  int n = strlen(s);
  int top = 0;
  st[0] = 12;
  for (i = 0; i < n; i++)
  {
        if (s[i] == '(' || s[i] == '[' || s[i] == '{') 
            st[++top] = s[i];
        if (s[i] == ')')
            if (st[top] != '(') 
            {
                puts("INVALID");
                return 0; 
            }
        else 
            top--;
        if (s[i] == ']')
            if (st[top] != '[') 
            {
                puts("INVALID");
                return 0; 
            }
            else 
                top--;
        if (s[i] == '}')
            if (st[top] != '{') 
            {
                puts("INVALID");
                return 0; 
            }
            else 
                top--;
  }
  if (top != 0) 
  {
    puts("INVALID");
    return 0;
  }
  puts("VALID");
}

