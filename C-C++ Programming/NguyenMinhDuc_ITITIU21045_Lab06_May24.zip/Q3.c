#include<stdio.h>
#include<string.h>
#include<conio.h>

int main()
{
    char string[200];
    int i, j, length = strlen(string);
    printf("Enter a string: ");
    gets(string);
    for(i=0; i<strlen(string); i++)
    {
        if(string[0]==' ')
        {
            for(i=0; i<(strlen(string)-1); i++)
                string[i] = string[i+1];
            string[i] = '\0';
            length--;
            i = -1;
            continue;
        }
        if(string[i]==' ' && string[i+1]==' ')
        {
            for(j=i; j<(strlen(string)-1); j++)
            {
                string[j] = string[j+1];
            }
            string[j] = '\0';
            length--;
            i--;
        }
    }
    printf("\nNew String = %s", string);
    getch();
    return 0;
}
