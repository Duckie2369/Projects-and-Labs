#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main()
{
    char string[100] = ""; 
    char word[20] = "";
    char longestWord[20] = "";
    char shortestWord[20] = "";
    int index=0;
    printf("Input the string: ");
    fgets(string, sizeof(string), stdin);

    for (int k=0; k < strlen(string); k++)
    {
        while ((k < strlen(string)) && (!isspace(string[k])) && (isalnum(string[k])))
        {
            word[index++] = string[k++];
        }
        if (index != 0)
            {
                word[index] = '\0';
                if (strlen(longestWord) == 0)
                {
                    strcpy(longestWord, word);
                }
                if (strlen(shortestWord) == 0)
                {
                    strcpy(shortestWord, word);
                }

                if (strlen(word) >= strlen(longestWord))
                {
                    strcpy(longestWord, word);
                }
                if (strlen(word) <= strlen(shortestWord))
                {
                    strcpy(shortestWord, word);
                }

                index=0;
            }
    }
    printf("Shortest word: \'%s\'\n", shortestWord);
    printf("Longest word: \'%s\'", longestWord);
    return 0;
}