#include <LPC17xx.h>
#include <PIN_LPC17xx.h>
#include <GPIO_LPC17xx.h>
#include <GLCD_Config.h>
#include <Board_GLCD.h>
#include <GLCD_Fonts.h>

#include <Driver_SPI.h>

char myString[]={"hello, world"};
 

int main( void ) {
	GLCD_Initialize()	;      
	GLCD_SetFont(&GLCD_Font_16x24)	;
	GLCD_SetBackgroundColor	(GLCD_COLOR_GREEN)	;
	GLCD_SetBackgroundColor	(GLCD_COLOR_LIGHT_GREY);
	GLCD_ClearScreen()	;
	GLCD_DrawRectangle(5,5,100,100);
	GLCD_DrawBargraph(100,150,50,50,20);
	GLCD_DrawString	(5,200,myString);
	while ( 1 ) {
	
	}
}