package Lab_3.Point2D_And_Point3D;

public class main {

	public static void main(String[] args) {
		Point2D p2 = new Point2D(4, 7);
		Point3D p3 = new Point3D(2, 3, 4);
		System.out.println(p2.toString());
		System.out.println();
		System.out.println(p3.toString());
	}
}
