package Lab_3.Shapes;

public class MyBoundedShape extends MyShape{
	public void GetArea(){}
}
