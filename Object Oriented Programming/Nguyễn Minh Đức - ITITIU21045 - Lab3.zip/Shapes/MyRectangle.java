package Lab_3.Shapes;

public class MyRectangle extends MyBoundedShape{
	private int length;
	private int width;
	
	public MyRectangle(int Length, int Width) {
		length = Length;
		width = Width;
	}
}
