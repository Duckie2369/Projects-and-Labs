package Lab_3.Shapes;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Select 5 shapes: ");
		String[] shape = new String[5];
		for (int k=0; k < 5; k++) {
			shape[k] = scan.next();
		}
		for (int i=0; i < 5; i++) {
			if ("Line".equals(shape[i])) {
				System.out.println("Input the length of the line: ");
				int dim = scan.nextInt();
				MyLine s = new MyLine(dim);
				s.Draw();
				System.out.println();
			}
			else if ("Oval".equals(shape[i])) {
				System.out.println("Input the long axis length: ");
				int long_axis = scan.nextInt();
				System.out.println("Input the short axis length: ");
				int short_axis = scan.nextInt();
				MyOval s = new MyOval(long_axis, short_axis);
				s.Draw();
				s.GetArea();
				System.out.println();
				System.out.println();
			}
			else {
				System.out.println("Input the length of the rectangle: ");
				int length = scan.nextInt();
				System.out.println("Input the width of the rectangle: ");
				int width = scan.nextInt();
				MyRectangle s = new MyRectangle(length, width);
				s.Draw();
				s.GetArea();
				System.out.println();
				System.out.println();
			}
		}
		
		scan.close();
	}

}
