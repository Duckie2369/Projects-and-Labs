package Lab_3.Shapes;

public class MyShape {
	public void Draw() {}
}
