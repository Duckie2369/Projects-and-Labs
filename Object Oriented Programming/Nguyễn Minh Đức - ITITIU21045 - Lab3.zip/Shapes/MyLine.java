package Lab_3.Shapes;

public class MyLine extends MyShape{
	private int length;

	public MyLine(int Length) {
		length = Length;
	}
}
