package Lab_3.Shapes;

public class MyOval extends MyBoundedShape{
	private int long_axis;
	private int short_axis;
	
	public MyOval(int LongAxis, int ShortAxis) {
		long_axis = LongAxis;
		short_axis = ShortAxis;
	}
}
