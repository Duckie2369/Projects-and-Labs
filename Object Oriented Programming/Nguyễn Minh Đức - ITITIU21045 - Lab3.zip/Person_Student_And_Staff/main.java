package Lab_3.Person_Student_And_Staff;

public class main {

	public static void main(String[] args) {
		Student s = new Student("Duc", "127 S Street", "IT", 2021, 33);
		System.out.println(s.toString());
		System.out.println();
		
		Staff staff = new Staff("Mai", "125 P Street", "IU", 5);
		System.out.println(staff.toString());
	}

}
