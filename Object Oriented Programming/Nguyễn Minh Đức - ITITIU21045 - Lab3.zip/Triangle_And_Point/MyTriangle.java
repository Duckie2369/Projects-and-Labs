package Lab_3.Triangle_And_Point;

public class MyTriangle extends MyPoint{
	private MyPoint v1 = new MyPoint();
	private MyPoint v2 = new MyPoint();
	private MyPoint v3 = new MyPoint();
	
	public MyTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
		v1.setX(x1);
		v1.setY(y1);
		v2.setX(x2);
		v2.setY(y2);
		v3.setX(x3);
		v3.setY(y3);
	}
	
	public MyTriangle(MyPoint V1, MyPoint V2, MyPoint V3) {
		v1 = V1;
		v2 = V2;
		v3 = V3;
	}
	
	public String toString() {
		return "My Triangle[v1=("+v1.getX()+","+v1.getY()+"),v2=("+v2.getX()+","+v2.getY()+"),v3=("+v3.getX()+","+v3.getY()+")]";
	}
	
	public double getPerimeter(MyPoint v, MyPoint u) {
		double side = v.distance(u);
		return side;
	}
	
	public String getType() {
		double side1 = getPerimeter(v1, v2);
		double side2 = getPerimeter(v2, v3);
		double side3 = getPerimeter(v1, v3);
		if ((side1 == side2) && (side2 == side3) && (side1 == side3)) {
			return "Equilateral";
		}
		
		else if (((side1 == side2) && (side1 != side3))||((side2 == side3) && (side2 != side1))||((side1 == side3) && (side1 != side2))) {
			return "Isosceles";
		}
		return "Scalene";
	}
}
