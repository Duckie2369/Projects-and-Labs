package Lab_3.Triangle_And_Point;

public class main {

	public static void main(String[] args) {
		MyTriangle triangle = new MyTriangle(2, 3, 4, 5, 3, 6);
		System.out.printf("%s\nThe triangle type: %s", triangle.toString(),triangle.getType());

	}

}
