package Lab_3.Triangle_And_Point;
import java.lang.Math;

public class MyPoint {
	private int x;
	private int y;
	
	public void setX(int X) {
		x = X;
	}
	
	public void setY(int Y) {
		y = Y;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public double distance(MyPoint source) {
		return Math.sqrt(Math.pow(this.x-source.x,2)+Math.pow(this.y-source.y,2));
	}
}
