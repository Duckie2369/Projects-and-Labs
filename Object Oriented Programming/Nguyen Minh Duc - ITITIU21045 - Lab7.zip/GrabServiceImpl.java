package Lab_6;

public class GrabServiceImpl implements TransportService{
	private int distance;
	@Override
	public double getPrice(int distance) {
		double pricePay;
		this.distance = distance;
		if (distance<=2) {
			pricePay = distance*0.5;
		}
		else {
			pricePay = 2*0.5 + (distance-2)*1;
		}
		return pricePay;
	}

	@Override
	public String getTransportService() {
		return "Grab";
	}

	@Override
	public int getDistance() {
		return distance;
	}
	
}
