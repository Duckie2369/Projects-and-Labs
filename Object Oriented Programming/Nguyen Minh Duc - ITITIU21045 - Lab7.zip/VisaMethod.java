package Lab_6;

public class VisaMethod implements PaymentMethod{
	
	private TransportService service;
	private double fee;
	private double balanceVisa;
	private double balanceVisaAfter;

	@Override
	public void Fee(int d) {
		fee = this.service.getPrice(d)*(99/100);
	}
	
	@Override
	public double getFee() {
		return fee;
	}
	
	@Override
	public void setBalance(double balance) {
		this.balanceVisa = balance;
	}
	
	@Override
	public double getBalanceAfter() {
		if (fee>balanceVisa) {
			balanceVisa+=10;
		}
		balanceVisaAfter = balanceVisa - fee;
		return balanceVisaAfter;
	}

	@Override
	public double getBalance() {
		return balanceVisa;
	}
}
