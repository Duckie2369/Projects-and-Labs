package Lab_6;

public interface TransportService {
	double getPrice(int distance);
	String getTransportService();
	int getDistance();
}
