package Lab_6;

public class IBankingMethodInjector implements PaymentMethodInjector{

	@Override
	public CustomerInterface getCustomerPayment() {
		return new Customer(new IBankingMethod());
	}

	@Override
	public DriverInterface getDriverPayment() {
		return new Driver(new IBankingMethod());
	}

}
