package Lab_6;

public class Customer implements CustomerInterface{
	private double balance;
	private TransportService ts;
	private PaymentMethod pm;
	private String customerStatus;
	private int distance;
	private VisaMethod visa = new VisaMethod();
	private EWalletMethod ewallet = new EWalletMethod();
	private IBankingMethod ibanking = new IBankingMethod();
	
	public Customer(TransportService ts) {
		this.ts = ts;
	}
	
	public Customer(PaymentMethod pm) {
		this.pm = pm;
	}
	
	@Override
	public double getTotalBalance() {
		return visa.getBalance()+ewallet.getBalance()+ibanking.getBalance();
	}

	@Override
	public void setDistance(int d) {
		this.distance = d;
	}	
	
	@Override
	public int getDistance() {
		return distance;
	}	
	
	@Override
	public void setStatus(String status) {
		this.customerStatus = status;
	}	
	
	@Override
	public String getStatus() {
		return customerStatus;
	}
	
	@Override
	public void purchasing(TransportService ts, PaymentMethod pm) {
		this.ts = ts;
		this.pm = pm;
		balance = pm.getBalance();
		balance -= ts.getPrice(distance);
	}

	@Override
	public void setBalanceVisa(double blVisa) {
		visa.setBalance(blVisa);
	}

	@Override
	public void setBalanceEWallet(double blEWallet) {
		ewallet.setBalance(blEWallet);
		
	}

	@Override
	public void setBalanceIBanking(double blIBanking) {
		ibanking.setBalance(blIBanking);
	}

	@Override
	public double getBalanceVisaAfter() {
		return visa.getBalanceAfter();
	}

	@Override
	public double getBalanceVisa() {
		return visa.getBalance();
	}

	@Override
	public double getBalanceEWalletAfter() {
		return ewallet.getBalanceAfter();
	}

	@Override
	public double getBalanceEWallet() {
		return ewallet.getBalance();
	}

	@Override
	public double getBalanceIBankingAfter() {
		return ibanking.getBalanceAfter();
	}

	@Override
	public double getBalanceIBanking() {
		return ibanking.getBalance();
	}
}
