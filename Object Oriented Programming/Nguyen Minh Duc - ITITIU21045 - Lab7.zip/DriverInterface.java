package Lab_6;

public interface DriverInterface {
	void calculatingMoney(TransportService ts, PaymentMethod pm);
}
