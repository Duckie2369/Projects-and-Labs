package Lab_6;

public class EWalletMethod implements PaymentMethod{

	private TransportService service;
	private double fee;
	private double percentFee;
	private double balanceEWallet;
	private double balanceEWalletAfter;
	private static int countTrans;
	
	@Override
	public void Fee(int d) {
		countTrans++;
		if (countTrans%3==0) {
			percentFee = 0.005;
		}
		else {
			percentFee = 0.008;
		}
		fee = this.service.getPrice(d)-this.service.getPrice(d)*percentFee;
	}
	
	@Override
	public double getFee() {
		return fee;
	}
	
	@Override
	public void setBalance(double balance) {
		this.balanceEWallet = balance;
	}

	@Override
	public double getBalanceAfter() {
		if (fee>balanceEWallet) {
			balanceEWallet+=10;
		}
		balanceEWalletAfter = balanceEWallet - fee;
		
		return balanceEWalletAfter;
	}

	@Override
	public double getBalance() {
		return balanceEWallet;
	}
}
