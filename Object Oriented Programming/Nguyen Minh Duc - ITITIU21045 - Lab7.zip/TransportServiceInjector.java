package Lab_6;

public interface TransportServiceInjector {
	public CustomerInterface getCustomerTransport();
	public DriverInterface getDriverTransport();
}
