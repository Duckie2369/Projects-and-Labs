package Lab_6;

public interface PaymentMethod {
	void Fee(int distance);
	double getBalance();
	double getFee();
	void setBalance(double balance);
	double getBalanceAfter();
}
