package Lab_6;

import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Main {

	@SuppressWarnings("null")
	public static void main(String[] args) {
		int randomCustomers = ThreadLocalRandom.current().nextInt(1, 11);
		CustomerInterface[] customers = new CustomerInterface[randomCustomers];
		TransportServiceInjector[] ts = new TransportServiceInjector[randomCustomers];
		PaymentMethodInjector[] pm = new PaymentMethodInjector[randomCustomers];
		Scanner scan = new Scanner(System.in);
		
		for(int a=0; a<randomCustomers;a++) {
			ts[a] = new GrabServiceInjector();
			customers[a] = ts[a].getCustomerTransport();
			pm[a] = new VisaMethodInjector();
			customers[a] = pm[a].getCustomerPayment();
			
			ts[a] = new GojekServiceInjector();
			customers[a] = ts[a].getCustomerTransport();
			pm[a] = new EWalletMethodInjector();
			customers[a] = pm[a].getCustomerPayment();
			
			ts[a] = new BeServiceInjector();
			customers[a] = ts[a].getCustomerTransport();
			pm[a] = new IBankingMethodInjector();
			customers[a] = pm[a].getCustomerPayment();
			
			System.out.printf("Enter customer %d's Visa balance: ",a+1);
			customers[a].setBalanceVisa(scan.nextDouble());
			System.out.printf("Enter customer %d's E-Wallet balance: ",a+1);
			customers[a].setBalanceEWallet(scan.nextDouble());
			System.out.printf("Enter customer %d's IBanking balance: ",a+1);
			customers[a].setBalanceIBanking(scan.nextDouble());
			
			
			
			
			
		}
		
		int randomDrivers = ThreadLocalRandom.current().nextInt(1, 11);
		Driver[] drivers = new Driver[randomDrivers];
		scan.close();
	}

}
