package Lab_6;

public interface PaymentMethodInjector {
	public CustomerInterface getCustomerPayment();
	public DriverInterface getDriverPayment();
}
