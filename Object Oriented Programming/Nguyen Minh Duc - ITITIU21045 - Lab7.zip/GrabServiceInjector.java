package Lab_6;

public class GrabServiceInjector implements TransportServiceInjector{

	@Override
	public CustomerInterface getCustomerTransport() {
		return new Customer(new GrabServiceImpl());
	}

	@Override
	public DriverInterface getDriverTransport() {
		return new Driver(new GrabServiceImpl());
	}

}
