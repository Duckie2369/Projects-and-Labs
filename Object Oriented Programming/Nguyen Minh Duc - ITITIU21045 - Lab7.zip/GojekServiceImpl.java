package Lab_6;

public class GojekServiceImpl implements TransportService{
	private int distance;
	@Override
	public double getPrice(int distance) {
		double pricePay;
		this.distance = distance;
		if (distance<=5) {
			pricePay = distance*0.7;
		}
		else {
			pricePay = 5*0.7 + (distance-5)*1.2;
		}
		return pricePay;
	}

	@Override
	public String getTransportService() {
		return "Gojek";
	}

	@Override
	public int getDistance() {
		return distance;
	}

}
