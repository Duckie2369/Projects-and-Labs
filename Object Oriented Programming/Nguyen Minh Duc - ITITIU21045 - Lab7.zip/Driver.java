package Lab_6;

public class Driver implements DriverInterface{
	private double balance;
	private TransportService ts;
	private PaymentMethod pm;
	private String driverStatus = "Free";
	private int distance;
	private VisaMethod visa;
	private EWalletMethod ewallet;
	private IBankingMethod ibanking;
	private Customer customer;
	
	public Driver(TransportService ts) {
		this.ts=ts;
	}
	
	public Driver(PaymentMethod pm) {
		this.pm=pm;
	}
	
	public void setBalance(double bl) {
		this.balance = bl;
	}
	
	public double getBalance() {
		return visa.getBalance()+ewallet.getBalance()+ibanking.getBalance();
	}

	public String getTransportService() {
		return ts.getTransportService();
	}	
	
	public String getStatus() {
		return driverStatus;
	}
	
	@Override
	public void calculatingMoney(TransportService ts, PaymentMethod pm) {
		this.ts = ts;
		this.pm = pm;
		balance = pm.getBalance();
		if (customer.getStatus()=="Booking" && driverStatus == "Free") {
			driverStatus = "Processing";
			customer.setStatus("Processing");
			distance = customer.getDistance();
			balance += ts.getPrice(distance)*0.8;
		}
		driverStatus = "Free";
		customer.setStatus("Booking");
	}
	
}
