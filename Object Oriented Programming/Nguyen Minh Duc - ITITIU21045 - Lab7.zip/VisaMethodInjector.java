package Lab_6;

public class VisaMethodInjector implements PaymentMethodInjector{

	@Override
	public CustomerInterface getCustomerPayment() {
		return new Customer(new VisaMethod());
	}

	@Override
	public DriverInterface getDriverPayment() {
		return new Driver(new VisaMethod());
	}

}
