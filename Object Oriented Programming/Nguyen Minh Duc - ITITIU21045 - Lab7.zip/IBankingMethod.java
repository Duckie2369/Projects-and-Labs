package Lab_6;

public class IBankingMethod implements PaymentMethod{

	private TransportService service;
	private double fee;
	private double balanceIBanking;
	private double balanceIBankingAfter;
	
	public IBankingMethod(TransportService svc) {
		this.service = svc;
	}
	
	public IBankingMethod() {
	}

	@Override
	public void Fee(int d) {
		fee = this.service.getPrice(d)*(99.5/100);
	}
	
	@Override
	public double getFee() {
		return fee;
	}

	@Override
	public void setBalance(double balance) {
		this.balanceIBanking = balance;
	}

	@Override
	public double getBalanceAfter() {
		balanceIBankingAfter = balanceIBanking - fee;
		return balanceIBankingAfter;
	}
	
	@Override
	public double getBalance() {
		return balanceIBanking;
	}
}
