package Lab_6;

public class BeServiceImpl implements TransportService{
	private int distance;
	@Override
	public double getPrice(int distance) {
		double pricePay;
		this.distance = distance;
		if (distance<=3) {
			pricePay = distance*0.5;
		}
		else {
			pricePay = 3*0.5 + (distance-3)*1.5;
		}
		return pricePay;
	}

	@Override
	public String getTransportService() {
		return "Be";
	}

	@Override
	public int getDistance() {
		return distance;
	}

}
