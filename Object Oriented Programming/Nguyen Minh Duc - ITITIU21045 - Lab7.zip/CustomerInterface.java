package Lab_6;

public interface CustomerInterface {
	void purchasing(TransportService ts, PaymentMethod pm);
	void setBalanceVisa(double blVisa);
	void setBalanceEWallet(double blEWallet);
	void setBalanceIBanking(double blIBanking);
	double getBalanceVisaAfter();
	double getBalanceVisa();
	double getBalanceEWalletAfter();
	double getBalanceEWallet();
	double getBalanceIBankingAfter();
	double getBalanceIBanking();
	double getTotalBalance();
	void setDistance(int d);
	int getDistance();
	void setStatus(String status);
	String getStatus();
}
