package Lab_6;

public class GojekServiceInjector implements TransportServiceInjector{

	@Override
	public CustomerInterface getCustomerTransport() {
		return new Customer(new GojekServiceImpl());
	}

	@Override
	public DriverInterface getDriverTransport() {
		return new Driver(new GojekServiceImpl());
	}

}
