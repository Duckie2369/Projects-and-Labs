package Lab_6;

public class BeServiceInjector implements TransportServiceInjector{

	@Override
	public CustomerInterface getCustomerTransport() {
		return new Customer(new BeServiceImpl());
	}

	@Override
	public DriverInterface getDriverTransport() {
		return new Driver(new BeServiceImpl());
	}
}
