package Lab_6;

public class EWalletMethodInjector implements PaymentMethodInjector{

	@Override
	public CustomerInterface getCustomerPayment() {
		return new Customer(new EWalletMethod());
	}

	@Override
	public DriverInterface getDriverPayment() {
		return new Driver(new EWalletMethod());
	}

}
