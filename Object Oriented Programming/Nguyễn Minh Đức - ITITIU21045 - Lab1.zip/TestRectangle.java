
public class TestRectangle {

	public static void main(String[] args) {
		Rectangle r1 = new Rectangle(4,2);
		Rectangle r2 = new Rectangle(2,3);
		Rectangle r3 = new Rectangle(4,4);
		Rectangle r4 = new Rectangle(3,2);
		Rectangle r5 = new Rectangle(2,4);
		
		r1.Visualize();
		System.out.println();
		r2.Visualize();
		System.out.println();
		r3.Visualize();
		System.out.println();
		r4.Visualize();
		System.out.println();
		r5.Visualize();
	}

}
