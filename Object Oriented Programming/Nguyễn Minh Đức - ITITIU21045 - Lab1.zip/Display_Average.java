import java.util.Scanner;
import java.util.ArrayList;

public class Display_Average {

	public static void main(String[] args) {
		ArrayList<Items> ItemsList = new ArrayList<Items>();
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the number of items in the order:");
        int OrderNum = scanner.nextInt();
        int ID=1;
        
        for(int i=0; i < OrderNum; i++){
            System.out.println("Enter the name of the item " + ID + ":");
            String Name = scanner.next();
            
            System.out.println("Enter the price of item " + ID + ":");
            double Price = scanner.nextDouble();
            
            ItemsList.add(new Items(ID, Name, Price));
            ID++;
        }
        
        Order order = new Order(1, ItemsList);
        System.out.println("The average cost of the order is "+ order.calculateAverageCost());
        
        scanner.close();
	}

}
