
public class Items {
	private int ID;
	private String name;
	private double price;
	
	public Items(int id, String Name, double Price) {
		this.ID = id;
		this.name = Name;
		this.price = Price;
	}
	
	public void setItemsID(int id) {
		this.ID = id;
	}
	
	public int getItemsID() {
		return ID;
	}
	
	public void setItemsName(String Name) {
		this.name = Name;
	}
	
	public String getItemsName() {
		return name;
	}
	
	public void setItemsPrice(double Price) {
		this.price = Price;
	}
	
	public double getItemsPrice() {
		return price;
	}
}
