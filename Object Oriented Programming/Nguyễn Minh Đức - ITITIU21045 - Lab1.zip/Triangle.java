
public class Triangle {
	private int length1;
	private int length2;
	private int length3;
	
	public int getLength1() {
		return length1;
	}
	
	public int getLength2() {
		return length2;
	}
	
	public int getLength3() {
		return length3;
	}
	
	public Triangle(int L1, int L2, int L3) {
		length1 = L1;
		length2 = L2;
		length3 = L3;
	}
	
	public String verify() {
		if (length1+length2<=length3 || length3+length2<=length1 || length3+length1<=length2) {
			return "Not Triangle";
		}
		else if(length1==length2 && length2==length3 && length1==length3) {
			return "Equilateral";
		}
		else if(length1 == length2 || length2 == length3 || length1 == length3) {
			return "Isosceles";
		}
		else {
			return "Scalene";
		}
	}
}
