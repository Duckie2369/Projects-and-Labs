
public class Rectangle {
	private int width;
	private int height;
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public Rectangle(int recWidth, int recHeight) {
		width = recWidth;
		height = recHeight;
		if (recWidth < 0 || recHeight < 0){
			System.out.println("Negative input found");
			recWidth = 1;
			recHeight = 1;
		}
	}
	
	public void Visualize() {
		for(int i=0; i < height; i++) {
			System.out.println();
			for(int j=0; j <=width; j++) {
				System.out.print("*");
			}
		}
	}
}
