import java.util.ArrayList;

public class Order {
	private int ID;
	private ArrayList<Items> ItemsList;
	
	public Order(int id, ArrayList<Items> itemsList) {
		ID = id;
		ItemsList = itemsList;
	}
	
	public void setOrderID(int id) {
		ID = id;
	}
	
	public int getOrderID() {
		return ID;
	}
	
	public void setOrderItemsList(ArrayList<Items> itemsList) {
		ItemsList = itemsList;
	}
	
	public void getOrderItemsList() {
		for(int i=0; i < ItemsList.size(); i++){
            System.out.println(ItemsList.get(i).getItemsID() + " " + ItemsList.get(i).getItemsName() + " " + ItemsList.get(i).getItemsPrice());
        }
	}
	
	public double calculateAverageCost() {
		double total = 0;
		for(int i=0; i < ItemsList.size(); i++){
            total += ItemsList.get(i).getItemsPrice();
        }
        return total/ItemsList.size();
	}
}
