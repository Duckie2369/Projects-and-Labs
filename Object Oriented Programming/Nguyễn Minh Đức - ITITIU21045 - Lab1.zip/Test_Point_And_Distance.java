
public class Test_Point_And_Distance {

	public static void main(String[] args) {
		Point A = new Point(2,3);
		Point B = new Point(4,6);
		
		System.out.println(A.distance(B));
	}

}
