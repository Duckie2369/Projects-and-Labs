
public class TestTriangle {

	public static void main(String[] args) {
		Triangle t1 = new Triangle(1, 2, 3);
		Triangle t2 = new Triangle(3, 3, 3);
		Triangle t3 = new Triangle(2, 2, 3);
		Triangle t4 = new Triangle(4, 2, 3);

		System.out.println(t1.verify());
		System.out.println(t2.verify());
		System.out.println(t3.verify());
		System.out.println(t4.verify());
		}

}
