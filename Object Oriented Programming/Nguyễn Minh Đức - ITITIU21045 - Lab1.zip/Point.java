
public class Point {
	private int x;
	private int y;
	
	public Point(int X, int Y) {
		x = X;
		y = Y;
	}
	
	public double distance(Point target) {
		return Math.sqrt(Math.pow((x - target.x),2)+Math.pow((y - target.y),2));
	}
}
