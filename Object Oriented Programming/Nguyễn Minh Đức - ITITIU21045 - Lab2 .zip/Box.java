package Lab_2;

public class Box {
	private static final int width = 20;
	private static final int height = 6;
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
}
