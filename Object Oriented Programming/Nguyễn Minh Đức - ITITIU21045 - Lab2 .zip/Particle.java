package Lab_2;

import java.util.Random;
import java.lang.Math;

public class Particle {
	private int x;
	private int y;
	Random rand = new Random();
	
	public int getRandomPosition(int min, int max) {
		return (int) ((Math.random()*(max - min)) + min);
	}
	
	public enum Directions{
		North,
		North_East,
		East,
		South_East,
		South,
		South_West,
		West,
		North_West;
		
		private static final Random random = new Random();
		
		public static Directions randomDirection() {
			Directions[] directions = values();
			return directions[random.nextInt(directions.length)];
		}
	}
	
	public void getDirection() {
		switch(Directions.randomDirection()) {
		case North:
			y -= 1;
			break;
			
		case North_East:
			y -= 1;
			x += 1;
			break;
			
		case East:
			x += 1;
			break;
			
		case South_East:
			y += 1;
			x += 1;
			break;
			
		case South:
			y += 1;
			break;
			
		case South_West:
			y += 1;
			x -= 1;
			break;
		
		case West:
			x -= 1;
			break;
			
		default:
			y -= 1;
			x -= 1;
			break;
		}
		if (x<0) {
			x = 0;
		}
		
		else if (x>box.getWidth()) {
			x = box.getWidth();
		}
		
		if (y<0) {
			y = 0;
		}
		
		else if (y>box.getHeight()) {
			y = box.getHeight();
		}
	}

	Box box = new Box();
	public Particle(int x_dir, int y_dir) {
		x = x_dir;
		y = y_dir;
		if (x<0) {
			x = 0;
		}
		
		else if (x>box.getWidth()) {
			x = box.getWidth();
		}
		
		if (y<0) {
			y = 0;
		}
		
		else if (y>box.getHeight()) {
			y = box.getHeight();
		}
	}
	
	public void setX(int X) {
		x = X;
	}
	
	public void setY(int Y) {
		y = Y;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public boolean checkCollision(Particle source, Particle support) {
		if ((Math.abs(support.x-source.x)==1) && (Math.abs(support.y-source.y)==1)){
			return true;
		}
		
		else if (Math.abs(support.x-source.x)==1) {
			return true;
		}
		
		else if (Math.abs(support.y-source.y)==1) {
			return true;
		}
		
		else if (support.x == source.x) {
			return true;
		}
		
		else if (support.y == source.y) {
			return true;
		}
		else {
			return false;
		}
		
	}
}
