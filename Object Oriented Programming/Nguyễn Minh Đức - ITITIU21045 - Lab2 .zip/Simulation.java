package Lab_2;

import java.util.Random;

public class Simulation {
	
	public static void main(String[] args) {
		Random rand = new Random();
		int step = 10;
		
		Box box = new Box();
		Particle[] particles = new Particle[100];
		particles[0] = new Particle(rand.nextInt(11), rand.nextInt(11));
		particles[1] = new Particle(rand.nextInt(11), rand.nextInt(11));
		particles[2] = new Particle(rand.nextInt(11), rand.nextInt(11));
		int countParticles = 3;
		int f = 0;
		System.out.println("Time #0");
		System.out.printf("Number of particles: %d\n",countParticles);
		for (int n=0; n < countParticles; n++) {
			System.out.printf("Position of p%d: x = %d, y = %d\n",n,particles[n].getX(), particles[n].getY());
		}
		System.out.println();
		
		
		while (true) {
			for (int i = 0; i < step; i++) {
				for (int k = 0; k < countParticles; k++) {
					particles[k].getDirection();
			}
			if (particles[0].checkCollision(particles[i], particles[i+1])) {
				countParticles += 1;
				particles[countParticles-1] = new Particle(rand.nextInt(11), rand.nextInt(11));
				System.out.printf("Time #%d\n", i+1);
				System.out.printf("Number of particles: %d\n",countParticles);
				for (int j=0; j < countParticles; j++) {
					System.out.printf("Position of p%d: x = %d, y = %d\n",j,particles[j].getX(), particles[j].getY());
				}
				System.out.println();
				
			}
			else {
				System.out.printf("Time #%d\n", i+1);
				System.out.printf("Number of particles: %d\n",countParticles);
				for (int m=0; m < countParticles; m++) {
					System.out.printf("Position of p%d: x = %d, y = %d\n",m,particles[m].getX(), particles[m].getY());
				}
				System.out.println();
			}
			System.out.println();
		}
		if (countParticles > 10) {
			break;
		}
		}
		for (int a=0; a < box.getHeight();a++) {
			if(a==0 || a==box.getHeight()-1) {
				for (int b=0; b < box.getWidth(); b++) {
					System.out.print("-");
				}
				System.out.println();
			}
			else{
				for (int c=0; c < box.getWidth(); c++) {
					if (c==0 || c==box.getWidth()-1) {
						System.out.print("|");
					}
					else {
						System.out.print(" ");
					}
				}
			System.out.println();
		}
		}
	
	}
	}






